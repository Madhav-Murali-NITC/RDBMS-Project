#include "Algebra.h"

#include <cstring>