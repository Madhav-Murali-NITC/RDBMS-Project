# nitcbase

The students will be implementing their code within this repository.
