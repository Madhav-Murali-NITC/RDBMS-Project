#include "OpenRelTable.h"


#include <cstring>
#include <cstdlib>

OpenRelTable::OpenRelTable(){

for(int i=0;i<MAX_OPEN; ++i){
RelCacheTable::relCache[i]=nullptr;
AttrCacheTable::attrCache[i]=nullptr;
}


//setting up relcat in the relations cache:



RecBuffer relCatBlock(RELCAT_BLOCK);

Attribute relCatRecord[RELCAT_NO_ATTRS];
relCatBlock.getRecord(relCatRecord,RELCAT_SLOTNUM_FOR_RELCAT);

struct RelCacheEntry relCacheEntry;

RelCacheTable::recordToRelCatEntry(relCatRecord,&relCacheEntry.relCatEntry);
relCacheEntry.recId.block = RELCAT_BLOCK;
relCacheEntry.recId.slot = RELCAT_SLOTNUM_FOR_RELCAT;


RelCacheTable::relCache[RELCAT_RELID] = (struct RelCacheEntry*)malloc(sizeof(RelCacheEntry));

*(RelCacheTable::relCache[RELCAT_RELID]) = relCacheEntry;



//setting up attr cat in the relations cache:-

Attribute attrCatRecord[ATTRCAT_NO_ATTRS];
relCatBlock.getRecord(attrCatRecord,RELCAT_SLOTNUM_FOR_ATTRCAT);

struct RelCacheEntry attrCacheEntry;

RelCacheTable::recordToRelCatEntry(attrCatRecord,&attrCacheEntry.relCatEntry);
attrCacheEntry.recId.block=ATTRCAT_BLOCK;
attrCacheEntry.recId.slot=RELCAT_SLOTNUM_FOR_ATTRCAT;

RelCacheTable::relCache[ATTRCAT_RELID] = (struct RelCacheEntry*)malloc(sizeof(RelCacheEntry));

*(RelCacheTable::relCache[ATTRCAT_RELID]) = attrCacheEntry;



RecBuffer attrCatBlock(ATTRCAT_BLOCK);
Attribute attrCatRecord1[ATTRCAT_NO_ATTRS];


struct AttrCacheEntry* prev = nullptr;
struct AttrCacheEntry* attrCacheHeadrel = nullptr;
for(int i=5;i>=0;i--){

struct AttrCacheEntry* attrCacheEntry = (struct AttrCacheEntry*)malloc(sizeof(struct AttrCacheEntry));

attrCatBlock.getRecord(attrCatRecord1, i);
AttrCacheTable::recordToAttrCatEntry(attrCatRecord1, &attrCacheEntry->attrCatEntry);
//data:-

attrCacheEntry->recId.block=ATTRCAT_BLOCK;

attrCacheEntry->recId.slot=i;

attrCacheEntry->next = attrCacheHeadrel;
attrCacheHeadrel = attrCacheEntry;

}

AttrCacheTable::attrCache[RELCAT_RELID] = attrCacheHeadrel;

//setting up the attrcat relation in the attr cache table:-
prev = nullptr;

struct AttrCacheEntry* attrCacheHeadattr = nullptr;



for(int i=11;i>=6;i--){

struct AttrCacheEntry* attrCacheEntry = (struct AttrCacheEntry*)malloc(sizeof(struct AttrCacheEntry));

attrCatBlock.getRecord(attrCatRecord1, i);
AttrCacheTable::recordToAttrCatEntry(attrCatRecord1, &attrCacheEntry->attrCatEntry);

//data:-
attrCacheEntry->recId.block=ATTRCAT_BLOCK;
attrCacheEntry->recId.slot=i;

attrCacheEntry->next = attrCacheHeadattr;
attrCacheHeadattr = attrCacheEntry;

}

AttrCacheTable::attrCache[ATTRCAT_RELID] = attrCacheHeadattr;
}














OpenRelTable::~OpenRelTable(){
for(int i=0;i<MAX_OPEN;++i){
free(RelCacheTable::relCache[i]);
}


for(int i=0;i<MAX_OPEN;++i){
struct AttrCacheEntry* current = AttrCacheTable::attrCache[i];
while(current!=nullptr){
struct AttrCacheEntry* next=current->next;
free(current);
current=next;
}
}
}






