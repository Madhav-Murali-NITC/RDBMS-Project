#include "BlockAccess.h"

#include <cstring>
